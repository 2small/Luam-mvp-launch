# Luam homepage — HTML + Tailwind CSS (v4)

Drop-in rebuild of `index.html` from the Nicepage export. Same look at 1440 / 1100 / 850 / 650 / 390 px
(pixel-compared against the original: <0.5% of pixels differ, all anti-aliasing / one small corner radius),
same links, same copy. No jQuery, no nicepage.js/css.

    npm install
    npm run build      # src/input.css + classes in index.html -> styles.css

Files: `index.html` (markup + Tailwind classes), `src/input.css` (theme: breakpoints, fonts, colours),
`main.js` (carousel, accordion, menus, scroll reveal, ~100 lines), `styles.css` (built output), `images/`.

Breakpoints are the Nicepage ones, so `max-xl:` = ≤1199px, `max-lg:` = ≤991px, `max-md:` = ≤767px, `max-sm:` = ≤575px.
Put this folder in place of the old `index.html`; the other pages (Therapy, Emergency, dashboard…) are untouched.

## Deliberate differences from the live page
- Mobile hamburger is visible (white). In the original it rendered invisible, so phones had no menu.
- Phone icon in the "Need help?" card is drawn (it was a blank circle).
- FAQ arrows stay at the right edge on phones (they were pushed off-screen).
- Parallax background (Peek section) is a plain fixed background instead of the skrollr script.

## Kept as-is (original quirks)
- Footer "Symmetry" link still points to `symmetry.html` (as before; the nav uses `dashboard.html`).
- Off-canvas menu on tablets lists FromLuam/Terms/Emergency/Home/Privacy/Blog (leftover second menu).
